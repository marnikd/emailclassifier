"""
This file contains model training and prediction.
"""

import joblib
import pandas as pd
import os

from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC




class Model:
    """
    This class is used to train the e-mail classification model and to make predictions based on the trained model.

    Attributes:
        pipeline_path: the location of the pipeline
    """
    def __init__(self, pipeline_path: Path):
        self.pipeline_path = pipeline_path

    def train_model(self, data: pd.DataFrame, regularization: int, penalty: str):
        """
        Create and save the created pipeline.

        Args:
            data: e-mail data which is used to train the model
            penalty: the norm used in the penalty in LinearSVC
            regularization: regularization parameter that is used in LinearSVC
        """
        # Define input and output parameters
        labels = data['Class Index']
        input_data = data['TitleDescription']

        # Create and fit pipeline
        svc_pipeline = self.fit_pipeline(input_data, labels, regularization, penalty)

        # Save pipeline
        os.makedirs(os.path.dirname(self.pipeline_path), exist_ok=True)
        joblib.dump(svc_pipeline, self.pipeline_path)

    @staticmethod
    def fit_pipeline(input_data: pd.Series, labels: pd.Series, regularization: int, penalty: str) -> Pipeline:
        """
        Preprocess data using TfidfVectorizer and train the e-mail classification model (Linear Support Vector
        Classifier).

        Args:
            input_data: e-mail title and description
            labels: class indices corresponding to the input data
            penalty: the norm used in the penalty in LinearSVC
            regularization: regularization parameter that is used in LinearSVC

        Returns:
            svc_pipeline: the fitted pipeline for classifying e-mails
        """
        # Define pipeline
        svc_pipeline = Pipeline([
            ('tfidf_vectorizer',
             TfidfVectorizer(stop_words='english', decode_error='ignore', tokenizer=LemmaTokenizer())),
            ('svc', LinearSVC())
        ])

        # Fit model with optimal parameters
        # TODO: FEATURE 1423 - Add hyperparameter tuning to model
        optimal_params = {'svc__C': regularization, 'svc__penalty': penalty}
        svc_pipeline.set_params(**optimal_params)
        svc_pipeline.fit(input_data, labels)

        return svc_pipeline

    def predict_new_data(self, data: pd.DataFrame) -> dict[int, int]:
        """
        Predict the departments for each e-mail in the data.

        Args:
            data: e-mails for which the department needs to be predicted

        Returns:
            prediction: e-mail ids and corresponding predicted departments
        """
        # Load pipeline
        pipeline = joblib.load(self.pipeline_path)

        # Define input
        X = data['TitleDescription']

        # Make predictions
        y_pred = pipeline.predict(X)

        mail_ids = list(data['ID'])
        prediction = {mail_id: pred for mail_id, pred in zip(mail_ids, y_pred)}

        return prediction

