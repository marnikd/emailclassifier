"""
The web service is being created in this file. The corresponding API functions can be used to train the e-mail
classification model and to make predictions based on this trained model.
"""

import os
import uvicorn

from fastapi import FastAPI, Form, Header, HTTPException
from pathlib import Path
from typing import Union

import version

from pipple_template.config import config
from pipple_template.data_preprocessing.preprocess_mail_data import MailDataPreprocessor
from pipple_template.data_validation.data_validation import DataValidator
from pipple_template.model.model import Model

logger = config.get_logger(__name__)
app_version = version.get_version()
project_root = config.get_project_root()

app = FastAPI()


@app.get("/ping")
async def ping() -> dict[str, str]:
    """
    Call to test the API connection.

    Returns:
        message: pong!
    """
    return {"message": "pong!"}


@app.post("/train")
async def train(content_type: str = Header(None), data: str = Form(...), delimiter: str = Form(...),
                quotechar: str = Form(...)) -> dict[str, Union[str, int]]:
    """
    Trains the e-mail classifier with new data and replaces the old classifier if necessary.

    Args:
        content_type: string containing the content type
        data: e-mail data that is used for training the e-mail classifier
        delimiter: delimiter of data
        quotechar: character used to denote the start and end of a quoted item

    Returns:
        response: message indicating whether the pipeline is saved successfully
    """
    # Load and check data
    logger.info("Start data loading and validation")
    data_validator = DataValidator()
    mail_data = data_validator.load_and_check_data(content_type, data, delimiter, quotechar, train=True)
    logger.info("Data was loaded and validated successfully")

    # Remove pipeline file if it exists
    pipeline_path = Path.joinpath(project_root, 'pipple_template/data/pipeline.pkl')

    if os.path.isfile(pipeline_path):
        os.remove(pipeline_path)

    try:
        # Data preprocessing
        logger.info("Start data preprocessing")
        data_preprocessor = MailDataPreprocessor()
        mail_data = data_preprocessor.preprocess_data(mail_data)
        logger.info("Data was preprocessed successfully")

        # Train model
        logger.info("Start model training")
        model = Model(pipeline_path)
        model.train_model(mail_data, regularization=1, penalty='l2')
        logger.info("The model is trained successfully")

        # Check if pipeline file is saved
        if not os.path.isfile(pipeline_path):
            logger.error("The trained model has not been saved")
            response = {"success": 0,
                        "content": "file is not saved"}
        else:
            logger.info("The trained model is saved successfully")
            response = {"success": 1,
                        "content": "model trained successfully"}
    except Exception as e:
        logger.error(f"Something went wrong while training the model: {e}")
        response = {"success": 0,
                    "content": str(e)}

    return response


@app.post("/predict")
async def predict(content_type: str = Header(None), data: str = Form(...), delimiter: str = Form(...),
                  quotechar: str = Form(...)) -> dict[str, Union[str, int]]:
    """
    Predicts the department for the e-mails in the data using the saved pipeline from the train call.

    Args:
        content_type: string containing the content type
        data: e-mail data for which the department needs to be predicted
        delimiter: delimiter of data
        quotechar: character used to denote the start and end of a quoted item

    Returns:
        response: message indicating whether the prediction was made successfully

    Raises:
        HTTPException: if pipeline file could not be found
    """
    # Check if pipeline file exists
    logger.info("Checking for trained model")
    pipeline_path = Path.joinpath(project_root, 'pipple_template/data/pipeline.pkl')

    if not os.path.isfile(pipeline_path):
        logger.error("The pipeline file could not be found")
        raise HTTPException(status_code=404, detail="Pipeline file not found. Train model first.")

    # Load and check data
    logger.info("Start data loading and validation")
    data_validator = DataValidator()
    mail_data = data_validator.load_and_check_data(content_type, data, delimiter, quotechar, train=False)
    logger.info("Data was loaded and validated successfully")

    try:
        # Data preprocessing
        logger.info("Start data preprocessing")
        data_preprocessor = MailDataPreprocessor()
        mail_data = data_preprocessor.preprocess_data(mail_data)
        logger.info("Data was preprocessed successfully")

        # Make predictions
        logger.info("Start prediction")
        model = Model(pipeline_path)
        predictions = model.predict_new_data(mail_data)
        response = {"success": 1,
                    "content": str(predictions)}
        logger.info("The prediction was made successfully")
    except Exception as e:
        logger.error(f"Something went wrong during predicting: {e}")
        response = {"success": 0,
                    "content": str(e)}

    return response


@app.on_event("shutdown")
async def shutdown():
    """
    Shutdown logging and app.
    """
    logger.info("Application shutting down")
    config.shutdown_logging()
    app.state.is_shutting_down = True


@app.on_event("startup")
async def startup():
    """
    Logging when application is started.
    """
    logger.info(f"Application started (version = {app_version})")


if __name__ == "__main__":
    logger.info("Application starting")

    # Get port
    port = config.get_uvicorn_port()
    logger.info(f"Starting server on port {port}")

    # Start uvicorn server to be able to make requests
    uvicorn.run("pipple_template.main:app", host="0.0.0.0", port=port, log_config=None)

    logger.info("Application finished")
