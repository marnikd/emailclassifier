"""
All data checks are defined in this file.
"""

import pandas as pd

from fastapi import HTTPException
from io import StringIO

from pipple_template.config import config

logger = config.get_logger(__name__)


class DataValidator:
    """
    This class is used to load and validate the incoming data for both training and predicting.
    """
    def __init__(self):
        pass

    def load_and_check_data(self, content_type: str, data: str, delimiter: str, quotechar: str,
                            train: bool) -> pd.DataFrame:
        """
        Load and check e-mail data and content type.

        Args:
            content_type: string containing the content type encoding
            data: e-mail data for which the department needs to be predicted
            delimiter: delimiter of data
            quotechar: character used to denote the start and end of a quoted item
            train: True if model needs to be trained, False if prediction needs to be made

        Returns:
            mail_data: e-mail data in DataFrame

        Raises:
            HTTPException if data format or content type is incorrect
        """
        # Check content type
        self.check_content_type(content_type)

        # Load data
        # TODO: USER STORY 1689 - Also accept JSON format
        if not isinstance(data, str):
            logger.error('E-mail data has incorrect data type')
            raise HTTPException(status_code=400, detail='Incorrect data type passed to application')

        data = StringIO(data)
        mail_data = pd.read_csv(data, sep=delimiter, quotechar=quotechar)
        self.check_data(mail_data, train=train)

        return mail_data

    @staticmethod
    def check_content_type(content_type: str):
        """
        Check if content type encoding is correct

        Args:
            content_type: content type encoding

        Raises:
            HTTPException: if content type is incorrect
        """
        if content_type != "application/x-www-form-urlencoded":
            logger.error('Incorrect content type encoding')
            raise HTTPException(status_code=400, detail="Incorrect content type encoding")

    @staticmethod
    def check_data(data: pd.DataFrame, train: bool):
        """
        Check if data has the correct format. This format is different for training the model and for making a
        prediction.

        Args:
            data: data that needs to be validated
            train: boolean indicating whether train data needs to be checked or prediction data

        Raises:
            HTTPException: if data has incorrect format
        """
        if data.shape[1] == 1:
            logger.error("Incorrect delimiter, check data for correct delimiter")
            raise HTTPException(status_code=400, detail="Incorrect delimiter, check data for correct delimiter")

        if data.isnull().values.any():
            logger.error("Data contains empty cells")
            raise HTTPException(status_code=400, detail="Data contains empty cells")

        if train:
            if list(data) != ['Class Index', 'Title', 'Description']:
                logger.error(f"Incorrect column names {str(list(data))}")
                raise HTTPException(status_code=400, detail=f"Incorrect column names {str(list(data))}")

            if not set(data['Class Index'].unique()).issubset({1, 2, 3, 4}):
                raise HTTPException(status_code=400, detail="Not all class indices are 1, 2, 3 or 4")
        else:
            if list(data) != ['ID', 'Title', 'Description']:
                raise HTTPException(status_code=400, detail=f"Incorrect column names {str(list(data))}")
