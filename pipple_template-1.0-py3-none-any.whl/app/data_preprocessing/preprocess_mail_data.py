"""
This file contains the data preparation that is needed for the e-mail classification model.
"""

import pandas as pd
import re

from xml.sax import saxutils as su


class MailDataPreprocessor:
    """
    This class contains methods that strip the original e-mail data from noise.
    """
    def __init__(self):
        pass

    def preprocess_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Create a new column for training and prediction and clean data.

        Args:
            data: original e-mail data

        Returns:
            data: preprocessed data
        """
        # Add combination of title and description to data
        data['TitleDescription'] = data['Title'] + " " + data['Description']

        # Delete unused columns
        del data['Title']
        del data['Description']

        # Decode html
        data["TitleDescription"] = data["TitleDescription"].apply(su.unescape)

        # Remove html tags
        data["TitleDescription"] = data["TitleDescription"].apply(self.remove_html_tags)

        # Remove quot; (this is not removed in the previous line)
        data["TitleDescription"] = data["TitleDescription"].str.replace("quot;", "")

        # Remove '#NAME?'
        data["TitleDescription"] = data["TitleDescription"].str.replace("#NAME?", "", regex=False)

        return data

    @staticmethod
    def remove_html_tags(text: str) -> str:
        """
        Remove html tags from a string.

        Args:
            text: text in which html tags need to be removed

        Returns:
            clean_text: original text without html tags
        """
        pattern = re.compile('<.*?>')
        clean_text = re.sub(pattern, '', text)

        return clean_text
