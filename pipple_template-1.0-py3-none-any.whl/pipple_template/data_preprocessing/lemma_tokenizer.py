"""
This file contains the lemmatizer that is used in the model pipeline.
"""

import nltk

from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

# Download nltk collections
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')


class LemmaTokenizer:
    """
    Lemmatizer that is used by TfidfVectorizer. This groups together inflected forms of a word to a single item,
    i.e. walk and walking.

    Attributes:
        wnl: type of lemmatizer
    """
    def __init__(self):
        self.wnl = WordNetLemmatizer()

    def __call__(self, doc: str) -> list[str]:
        """
im        Lemmatize all words in a document.
        
        Args:
            doc: all words that need to be lemmatized

        Returns:
            lemmatized_doc: list of words that are lemmatized
        """
        lemmatized_doc = [self.wnl.lemmatize(word=word, pos='v') for word in word_tokenize(doc)]
        
        return lemmatized_doc
