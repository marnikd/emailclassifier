"""
This file contains fixtures for all tests.
"""

import logging
import pytest

from pathlib import Path


def pytest_configure():
    # Disable logging when testing
    logging.disable(logging.CRITICAL)


@pytest.fixture(scope="session")
def project_root():
    # Fixture for project root
    project_root = Path(__file__).parents[1]

    return project_root


@pytest.fixture(scope="session")
def train_data(project_root):
    # Define train data for model
    input_source = Path.joinpath(project_root, 'tests/data/input/train_data.csv')

    with open(input_source, 'r') as source:
        train_data = source.read()

    return train_data


@pytest.fixture(scope="session")
def test_data(project_root):
    # Define test data for prediction
    input_source = Path.joinpath(project_root, 'tests/data/input/test_data.csv')

    with open(input_source, 'r') as source:
        test_data = source.read()

    return test_data
