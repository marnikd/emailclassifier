"""
Test if the right version is retrieved in the version directory.
"""

import os

from pathlib import Path

import version


def test_get_version_file(project_root):
    # Save version.txt
    version_filepath = Path.joinpath(project_root, 'version/version.txt')

    with open(version_filepath, 'w') as file:
        file.writelines("test")

    # Get version from file
    version_output = version.get_version()

    # Check if correct version is returned
    assert version_output == "test"

    # Remove version file
    os.remove(version_filepath)


def test_get_version_git(mocker):
    call_git_mock = mocker.patch('version._call_git')

    version.get_version()

    # Check if call git is called
    call_git_mock.assert_called_once()
