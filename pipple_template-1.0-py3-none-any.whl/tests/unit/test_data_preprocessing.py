import pandas as pd
import pytest

from pipple_template.data_preprocessing.preprocess_mail_data import MailDataPreprocessor


@pytest.fixture
def data_preprocessor():
    return MailDataPreprocessor()


def return_input(_, value):
    # Return the input value when mocking remove_html_tags
    return value


def test_remove_html_tags(data_preprocessor):
    html_text = "<h1>This is an example text<br> with <strong>HTML</strong> tags</h1>"

    clean_text = data_preprocessor.remove_html_tags(html_text)

    # Check if HTML tags are removed
    assert clean_text == "This is an example text with HTML tags"


def test_preprocess_data(data_preprocessor, mocker):
    mocker.patch('pipple_template.data_preprocessing.preprocess_mail_data.MailDataPreprocessor.remove_html_tags',
                 return_input)

    # Create input data
    mail_data = {'Title': ["Example #1",
                           "Second example!",
                           "Number 3"],
                 'Description': ["&lt;strong&gt;Example&lt;/strong&gt; description can be found here.",
                                 "This is the quot; description... quot;",
                                 "#NAME?"],
                 'Class Index': [3, 2, 1]}

    input_data = pd.DataFrame.from_dict(mail_data)

    # Preprocess data
    cleaned_data = data_preprocessor.preprocess_data(input_data)

    # Construct reference data
    # Note that HTML tags are not removed since remove_html_tags is mocked
    cleaned_mail_data = {'Class Index': [3, 2, 1],
                         'TitleDescription': ["Example #1 <strong>Example</strong> description can be found here.",
                                              "Second example! This is the  description... ",
                                              "Number 3 "]}
    reference_data = pd.DataFrame.from_dict(cleaned_mail_data)

    # Check if cleaned data is the right format and has the right values
    assert type(cleaned_data) is pd.DataFrame
    pd.testing.assert_frame_equal(cleaned_data, reference_data)
