"""
Test functions in config.py, such as reading the config and parameters files.
"""

import logging
import pytest

from pathlib import Path

import pipple_template

from pipple_template.config import config


def test_get_project_root():
    # Get project root
    project_root = config.get_project_root()

    # Check if project root contains name
    assert hasattr(project_root, 'name')

    # Extract last directory
    project_dir = project_root.name

    # Check if last directory is correct
    assert project_dir == 'pipple_template'


@pytest.mark.parametrize("config_filename", ['config_dev.yml', 'config_test.yml', 'config_acc.yml', 'config_prod.yml'])
def test_read_config_parameters(config_filename, project_root, mocker):
    # Test reading the config and parameter file
    # Mock project root
    mocker.patch('pipple_template.config.config.get_project_root', return_value=project_root)

    # Read config file including parameter file
    config_path = Path.joinpath(project_root, 'config', config_filename)
    config_file = config.read_config(config_path)

    # Check config file keys
    assert list(config_file.keys()) == ['logging', 'uvicorn']

    # Check logging keys
    assert list(config_file['logging'].keys()) == ['version', 'disable_existing_loggers', 'formatters', 'handlers',
                                                   'loggers', 'root']


def test_read_config_no_parameters(project_root, mocker):
    # Test read config if parameter file does not exist
    # Mock project root
    mocker.patch('pipple_template.config.config.get_project_root', return_value=Path('./non/existing/path'))

    # Read config file excluding parameter file
    config_path = Path.joinpath(project_root, 'config/config_dev.yml')
    config_file = config.read_config(config_path)

    # Check config file keys
    assert list(config_file.keys()) == ['logging']


def test_read_config_non_existing_path():
    # Read config file with non-existing path
    with pytest.raises(FileNotFoundError):
        config.read_config(Path('./non/existing/path'))


def test_get_logger():
    logger = config.get_logger('__main__')

    # Check logger type and name
    assert type(logger) is logging.Logger
    assert logger.name == '__main__'


def test_get_uvicorn_port():
    port = config.get_uvicorn_port()

    # Check if port is read from parameters file
    assert port == 8000


@pytest.mark.parametrize("config_file", [{}, {'uvicorn': {}}])
def test_get_default_uvicorn_port_no_uvicorn(config_file, mocker):
    # Mock config file
    mocker.patch.object(pipple_template.config.config, 'config', config_file)

    port = config.get_uvicorn_port()

    # Check if default port is returned
    assert port == 8001


def test_shutdown_logging(mocker):
    shutdown_mock = mocker.patch('logging.shutdown')
    config.shutdown_logging()

    # Check if shutdown is called
    shutdown_mock.assert_called_once()
