from pipple_template.data_preprocessing.lemma_tokenizer import LemmaTokenizer


def test_lemmatizer():
    lemmatizer = LemmaTokenizer()

    example_text = "This example text is to illustrate the behaviour of the lemmatizer. Therefore I randomly type " \
                   "that I have painted a painting."
    output_text = lemmatizer.__call__(example_text)

    # Check if text is lemmatized correctly
    assert output_text == ['This', 'example', 'text', 'be', 'to', 'illustrate', 'the', 'behaviour', 'of', 'the',
                           'lemmatizer', '.', 'Therefore', 'I', 'randomly', 'type', 'that', 'I', 'have', 'paint', 'a',
                           'paint', '.']
