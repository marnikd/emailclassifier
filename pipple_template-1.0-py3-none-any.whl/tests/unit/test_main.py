import pytest

from pathlib import Path
from fastapi.testclient import TestClient

from pipple_template.main import app


# All tests in this file are marked as webtests
pytestmark = pytest.mark.webtest


@pytest.fixture
def client():
    return TestClient(app)


def test_ping(client):
    response = client.get("/ping")
    assert response.status_code == 200
    assert response.json() == {"message": "pong!"}


def test_train_no_file(client, train_data, mocker):
    # Mock train model function such that pipeline is not saved
    mocker.patch('pipple_template.model.model.Model.train_model')

    # Train model
    form_data = {"data": train_data,
                 "delimiter": ",",
                 "quotechar": '"'}

    train_response = client.post("/train",
                                 data=form_data,
                                 headers={'Content-Type': 'application/x-www-form-urlencoded'})

    # Check response
    assert train_response.status_code == 200
    assert train_response.json() == {"success": "0", "content": "file is not saved"}


def test_train_exception(client, train_data, mocker):
    # Mock train model function such that exception is raised
    mocker.patch('pipple_template.model.model.Model.train_model', side_effect=Exception("ERROR! ERROR!"))

    # Train model
    form_data = {"data": train_data,
                 "delimiter": ",",
                 "quotechar": '"'}

    train_response = client.post("/train",
                                 data=form_data,
                                 headers={'Content-Type': 'application/x-www-form-urlencoded'})

    # Check response
    assert train_response.status_code == 200
    assert train_response.json() == {"success": "0", "content": "ERROR! ERROR!"}


def test_predict_no_pipeline(client, project_root, test_data, mocker):
    # Mock pipeline path with non-existent path
    pipeline_path = Path.joinpath(project_root, 'non/existent/path/pipeline.pkl')
    mocker.patch('pathlib.Path.joinpath', return_value=pipeline_path)

    # Predict new data
    form_data = {"data": test_data,
                 "delimiter": ",",
                 "quotechar": '"'}
    predict_response = client.post("/predict",
                                   data=form_data,
                                   headers={'Content-Type': 'application/x-www-form-urlencoded'})

    # Check response
    assert predict_response.status_code == 404
    assert predict_response.json() == {"detail": "Pipeline file not found. Train model first."}


def test_predict_exception(client, project_root, test_data, mocker):
    # Mock pipeline path with test pipeline
    pipeline_path = Path.joinpath(project_root, 'tests/data/input/pipeline.pkl')
    mocker.patch('pathlib.Path.joinpath', return_value=pipeline_path)

    # Mock predict function such that exception is raised
    mocker.patch('pipple_template.model.model.Model.predict_new_data', side_effect=Exception("ERROR! ERROR!"))

    # Predict new data
    form_data = {"data": test_data,
                 "delimiter": ",",
                 "quotechar": '"'}
    predict_response = client.post("/predict",
                                   data=form_data,
                                   headers={'Content-Type': 'application/x-www-form-urlencoded'})

    # Check response
    assert predict_response.status_code == 200
    assert predict_response.json() == {"success": "0", "content": "ERROR! ERROR!"}
