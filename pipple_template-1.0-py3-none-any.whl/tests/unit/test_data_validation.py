import pandas as pd
import pytest

from fastapi import HTTPException

from pipple_template.data_validation.data_validation import DataValidator


@pytest.fixture
def data_validator():
    return DataValidator()


def test_check_content_type(data_validator):
    # Check content type should not raise an exception
    try:
        data_validator.check_content_type("application/x-www-form-urlencoded")
    except HTTPException:
        assert False


def test_check_content_type_error(data_validator):
    # Check if check content type raises exception when incorrect content type is passed
    with pytest.raises(HTTPException):
        data_validator.check_content_type("incorrect_content_type")


def test_check_data(data_validator):
    data = pd.DataFrame([[1, "Example title", "Example description"]], columns=["Class Index", "Title", "Description"])

    # Check data should not raise an exception
    try:
        data_validator.check_data(data, train=True)
    except HTTPException:
        assert False


def test_check_data_wrong_delimiter(data_validator):
    data = pd.DataFrame([['1,"Example title","Example description"']], columns=["Class Index,Title,Description"])

    # Check if check data raises exception when incorrect delimiter is passed
    with pytest.raises(HTTPException):
        data_validator.check_data(data, train=True)


def test_check_data_empty_cells(data_validator):
    data = pd.DataFrame([[1, float('nan'), "Example description"]], columns=["Class Index", "Title", "Description"])

    # Check if check data raises exception when empty values are passed
    with pytest.raises(HTTPException):
        data_validator.check_data(data, train=True)


def test_check_data_train_incorrect_column_names(data_validator):
    data = pd.DataFrame([[1, "Example title", "Example description"]],
                        columns=["Incorrect name", "Title", "Description"])

    # Check if check data raises exception when incorrect column names are passed
    with pytest.raises(HTTPException):
        data_validator.check_data(data, train=True)


def test_check_data_test_incorrect_column_names(data_validator):
    data = pd.DataFrame([[1, "Example title", "Example description"]],
                        columns=["Incorrect name", "Title", "Description"])

    # Check if check data raises exception when incorrect column names are passed
    with pytest.raises(HTTPException):
        data_validator.check_data(data, train=False)


def test_check_data_train_incorrect_class_index(data_validator):
    data = pd.DataFrame([[1, "Example title", "Example description"], [0, "Example title", "Example description"]],
                        columns=["Class Index", "Title", "Description"])

    # Check if check data raises exception when incorrect class indices are passed
    with pytest.raises(HTTPException):
        data_validator.check_data(data, train=True)


def test_load_and_check_data(data_validator, mocker):
    content_type_mock = mocker.patch('pipple_template.data_validation.data_validation.DataValidator.check_content_type')
    check_data_mock = mocker.patch('pipple_template.data_validation.data_validation.DataValidator.check_data')

    data = """Class Index,Title,Description
    1,"Example title","Example description"
    """

    mail_data = data_validator.load_and_check_data(content_type="some_content_type", data=data, delimiter=',',
                                                   quotechar='"', train=True)

    # Check if check content type and check data are called once
    content_type_mock.assert_called_once()
    check_data_mock.assert_called_once()

    # Check if correct data is returned
    assert type(mail_data) is pd.DataFrame
    pd.testing.assert_frame_equal(mail_data, pd.DataFrame([[1, "Example title", "Example description"]],
                                                          columns=["Class Index", "Title", "Description"]))


def test_load_and_check_data_incorrect_format(data_validator, mocker):
    content_type_mock = mocker.patch('pipple_template.data_validation.data_validation.DataValidator.check_content_type')
    mocker.patch('pipple_template.data_validation.data_validation.DataValidator.check_data')

    with pytest.raises(HTTPException):
        data_validator.load_and_check_data(content_type="some_content_type", data=127, delimiter=',', quotechar='"',
                                           train=True)

    # Check if check content type and check data are called once
    content_type_mock.assert_called_once()

