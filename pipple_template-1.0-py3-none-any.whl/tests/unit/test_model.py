import os
import pandas as pd
import pytest

from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.utils.validation import check_is_fitted

from pipple_template.data_preprocessing.lemma_tokenizer import LemmaTokenizer
from pipple_template.model.model import Model


@pytest.fixture
def train_pipeline_path(project_root):
    pipeline_path = Path.joinpath(project_root, 'tests/data/output/pipeline.pkl')
    return pipeline_path


@pytest.fixture
def model_for_training(train_pipeline_path):
    return Model(train_pipeline_path)


def test_fit_pipeline(model_for_training):
    input_data = pd.Series(["Example #1 Example description can be found here.",
                            "Second example! This is the description... ",
                            "Number 3 "])
    labels = pd.Series([3, 2, 1])

    pipeline = model_for_training.fit_pipeline(input_data, labels, regularization=2, penalty='l2')

    # Check pipeline steps
    assert list(pipeline.named_steps.keys()) == ['tfidf_vectorizer', 'svc']

    # Check if pipeline is fitted
    try:
        check_is_fitted(pipeline)
    except:
        assert False

    # Check TfidfVectorzier type and parameters
    assert type(pipeline['tfidf_vectorizer']) is TfidfVectorizer

    tfidf_params = pipeline['tfidf_vectorizer'].get_params()
    assert tfidf_params['stop_words'] == 'english'
    assert tfidf_params['decode_error'] == 'ignore'
    assert type(tfidf_params['tokenizer']) is LemmaTokenizer

    # Check LinearSVC type and parameters
    assert type(pipeline['svc']) is LinearSVC

    svc_params = pipeline['svc'].get_params()
    assert svc_params['C'] == 2
    assert svc_params['penalty'] == 'l2'


def test_train_model(model_for_training, train_pipeline_path):
    # Define train data
    train_data = {'Class Index': [3, 2, 1],
                  'TitleDescription': ["Example #1 Example description can be found here.",
                                       "Second example! This is the description... ",
                                       "Number 3 "]}
    train_data = pd.DataFrame.from_dict(train_data)

    # Train model
    model_for_training.train_model(data=train_data, regularization=2, penalty='l2')

    # Check if pipeline is saved
    assert os.path.exists(train_pipeline_path)

    # Delete pipeline
    os.remove(train_pipeline_path)


def test_predict_new_data(project_root):
    # Define pipeline path and model
    pipeline_path = Path.joinpath(project_root, 'tests/data/input/pipeline.pkl')
    model = Model(pipeline_path)

    # Define new data
    new_data = {'ID': [1, 2, 3],
                'TitleDescription': ["Example #1 Example description can be found here.",
                                     "Second example! This is the description... ",
                                     "Number 3 "]}
    new_data = pd.DataFrame.from_dict(new_data)

    # Make prediction
    prediction = model.predict_new_data(new_data)

    # Check if predictions are correct
    assert prediction == {1: 2, 2: 1, 3: 4}
